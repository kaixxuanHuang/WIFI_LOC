package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * ap对象 tb_ap
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
public class TbAp extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    @Excel(name = "编号")
    private Long apId;

    /** wifi名称 */
    @Excel(name = "wifi名称")
    private String apName;

    /** 物理地址 */
    @Excel(name = "物理地址")
    private String apMac;

    /** x轴坐标 */
    @Excel(name = "x轴坐标")
    private Double apX;

    /** y轴坐标 */
    @Excel(name = "y轴坐标")
    private Double apY;

    /** 场景编号 */
    @Excel(name = "场景编号")
    private Long sceneId;

    public void setApId(Long apId) 
    {
        this.apId = apId;
    }

    public Long getApId() 
    {
        return apId;
    }
    public void setApName(String apName) 
    {
        this.apName = apName;
    }

    public String getApName() 
    {
        return apName;
    }
    public void setApMac(String apMac) 
    {
        this.apMac = apMac;
    }

    public String getApMac() 
    {
        return apMac;
    }
    public void setApX(Double apX)
    {
        this.apX = apX;
    }

    public Double getApX()
    {
        return apX;
    }
    public void setApY(Double apY)
    {
        this.apY = apY;
    }

    public Double getApY()
    {
        return apY;
    }
    public void setSceneId(Long sceneId) 
    {
        this.sceneId = sceneId;
    }

    public Long getSceneId() 
    {
        return sceneId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("apId", getApId())
            .append("apName", getApName())
            .append("apMac", getApMac())
            .append("apX", getApX())
            .append("apY", getApY())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("sceneId", getSceneId())
            .toString();
    }
}
