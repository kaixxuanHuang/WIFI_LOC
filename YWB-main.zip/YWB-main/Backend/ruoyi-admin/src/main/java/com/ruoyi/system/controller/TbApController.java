package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.TbAp;
import com.ruoyi.system.service.ITbApService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * apController
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
@RestController
@RequestMapping("/system/ap")
public class TbApController extends BaseController
{
    @Autowired
    private ITbApService tbApService;

    /**
     * 查询ap列表
     */
    @PreAuthorize("@ss.hasPermi('system:ap:list')")
    @GetMapping("/list")
    public TableDataInfo list(TbAp tbAp)
    {
        startPage();
        List<TbAp> list = tbApService.selectTbApList(tbAp);
        return getDataTable(list);
    }

    /**
     * 导出ap列表
     */
    @PreAuthorize("@ss.hasPermi('system:ap:export')")
    @Log(title = "ap", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TbAp tbAp)
    {
        List<TbAp> list = tbApService.selectTbApList(tbAp);
        ExcelUtil<TbAp> util = new ExcelUtil<TbAp>(TbAp.class);
        util.exportExcel(response, list, "ap数据");
    }

    /**
     * 获取ap详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:ap:query')")
    @GetMapping(value = "/{apId}")
    public AjaxResult getInfo(@PathVariable("apId") Long apId)
    {
        return success(tbApService.selectTbApByApId(apId));
    }

    /**
     * 新增ap
     */
    @PreAuthorize("@ss.hasPermi('system:ap:add')")
    @Log(title = "ap", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TbAp tbAp)
    {
        return toAjax(tbApService.insertTbAp(tbAp));
    }

    /**
     * 修改ap
     */
    @PreAuthorize("@ss.hasPermi('system:ap:edit')")
    @Log(title = "ap", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TbAp tbAp)
    {
        return toAjax(tbApService.updateTbAp(tbAp));
    }

    /**
     * 删除ap
     */
    @PreAuthorize("@ss.hasPermi('system:ap:remove')")
    @Log(title = "ap", businessType = BusinessType.DELETE)
	@DeleteMapping("/{apIds}")
    public AjaxResult remove(@PathVariable Long[] apIds)
    {
        return toAjax(tbApService.deleteTbApByApIds(apIds));
    }
}
