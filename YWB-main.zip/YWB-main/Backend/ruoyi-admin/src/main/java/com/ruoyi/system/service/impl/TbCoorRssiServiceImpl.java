package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.TbCoorRssiMapper;
import com.ruoyi.system.domain.TbCoorRssi;
import com.ruoyi.system.service.ITbCoorRssiService;

/**
 * 指纹库管理Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-02-21
 */
@Service
public class TbCoorRssiServiceImpl implements ITbCoorRssiService 
{
    @Autowired
    private TbCoorRssiMapper tbCoorRssiMapper;

    /**
     * 查询指纹库管理
     * 
     * @param crId 指纹库管理主键
     * @return 指纹库管理
     */
    @Override
    public TbCoorRssi selectTbCoorRssiByCrId(Long crId)
    {
        return tbCoorRssiMapper.selectTbCoorRssiByCrId(crId);
    }

    /**
     * 查询指纹库管理列表
     * 
     * @param tbCoorRssi 指纹库管理
     * @return 指纹库管理
     */
    @Override
    public List<TbCoorRssi> selectTbCoorRssiList(TbCoorRssi tbCoorRssi)
    {
        return tbCoorRssiMapper.selectTbCoorRssiList(tbCoorRssi);
    }

    /**
     * 新增指纹库管理
     * 
     * @param tbCoorRssi 指纹库管理
     * @return 结果
     */
    @Override
    public int insertTbCoorRssi(TbCoorRssi tbCoorRssi)
    {
        tbCoorRssi.setCreateTime(DateUtils.getNowDate());
        return tbCoorRssiMapper.insertTbCoorRssi(tbCoorRssi);
    }

    /**
     * 修改指纹库管理
     * 
     * @param tbCoorRssi 指纹库管理
     * @return 结果
     */
    @Override
    public int updateTbCoorRssi(TbCoorRssi tbCoorRssi)
    {
        tbCoorRssi.setUpdateTime(DateUtils.getNowDate());
        return tbCoorRssiMapper.updateTbCoorRssi(tbCoorRssi);
    }

    /**
     * 批量删除指纹库管理
     * 
     * @param crIds 需要删除的指纹库管理主键
     * @return 结果
     */
    @Override
    public int deleteTbCoorRssiByCrIds(Long[] crIds)
    {
        return tbCoorRssiMapper.deleteTbCoorRssiByCrIds(crIds);
    }

    /**
     * 删除指纹库管理信息
     * 
     * @param crId 指纹库管理主键
     * @return 结果
     */
    @Override
    public int deleteTbCoorRssiByCrId(Long crId)
    {
        return tbCoorRssiMapper.deleteTbCoorRssiByCrId(crId);
    }
}
