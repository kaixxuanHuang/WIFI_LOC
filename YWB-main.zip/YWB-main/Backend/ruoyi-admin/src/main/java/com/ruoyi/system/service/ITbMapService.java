package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.TbMap;

/**
 * mapService接口
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
public interface ITbMapService 
{
    /**
     * 查询map
     * 
     * @param mapId map主键
     * @return map
     */
    public TbMap selectTbMapByMapId(Long mapId);

    /**
     * 查询map列表
     * 
     * @param tbMap map
     * @return map集合
     */
    public List<TbMap> selectTbMapList(TbMap tbMap);

    /**
     * 新增map
     * 
     * @param tbMap map
     * @return 结果
     */
    public int insertTbMap(TbMap tbMap);

    /**
     * 修改map
     * 
     * @param tbMap map
     * @return 结果
     */
    public int updateTbMap(TbMap tbMap);

    /**
     * 批量删除map
     * 
     * @param mapIds 需要删除的map主键集合
     * @return 结果
     */
    public int deleteTbMapByMapIds(Long[] mapIds);

    /**
     * 删除map信息
     * 
     * @param mapId map主键
     * @return 结果
     */
    public int deleteTbMapByMapId(Long mapId);
}
