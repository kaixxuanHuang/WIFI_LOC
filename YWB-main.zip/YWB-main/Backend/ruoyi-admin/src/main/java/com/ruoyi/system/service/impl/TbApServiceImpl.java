package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.TbApMapper;
import com.ruoyi.system.domain.TbAp;
import com.ruoyi.system.service.ITbApService;

/**
 * apService业务层处理
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
@Service
public class TbApServiceImpl implements ITbApService 
{
    @Autowired
    private TbApMapper tbApMapper;

    /**
     * 查询ap
     * 
     * @param apId ap主键
     * @return ap
     */
    @Override
    public TbAp selectTbApByApId(Long apId)
    {
        return tbApMapper.selectTbApByApId(apId);
    }

    /**
     * 查询ap列表
     * 
     * @param tbAp ap
     * @return ap
     */
    @Override
    public List<TbAp> selectTbApList(TbAp tbAp)
    {
        return tbApMapper.selectTbApList(tbAp);
    }

    /**
     * 新增ap
     * 
     * @param tbAp ap
     * @return 结果
     */
    @Override
    public int insertTbAp(TbAp tbAp)
    {
        tbAp.setCreateTime(DateUtils.getNowDate());
        return tbApMapper.insertTbAp(tbAp);
    }

    /**
     * 修改ap
     * 
     * @param tbAp ap
     * @return 结果
     */
    @Override
    public int updateTbAp(TbAp tbAp)
    {
        tbAp.setUpdateTime(DateUtils.getNowDate());
        return tbApMapper.updateTbAp(tbAp);
    }

    /**
     * 批量删除ap
     * 
     * @param apIds 需要删除的ap主键
     * @return 结果
     */
    @Override
    public int deleteTbApByApIds(Long[] apIds)
    {
        return tbApMapper.deleteTbApByApIds(apIds);
    }

    /**
     * 删除ap信息
     * 
     * @param apId ap主键
     * @return 结果
     */
    @Override
    public int deleteTbApByApId(Long apId)
    {
        return tbApMapper.deleteTbApByApId(apId);
    }
}
