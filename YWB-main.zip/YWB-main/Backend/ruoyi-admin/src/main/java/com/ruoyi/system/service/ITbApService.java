package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.TbAp;

/**
 * apService接口
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
public interface ITbApService 
{
    /**
     * 查询ap
     * 
     * @param apId ap主键
     * @return ap
     */
    public TbAp selectTbApByApId(Long apId);

    /**
     * 查询ap列表
     * 
     * @param tbAp ap
     * @return ap集合
     */
    public List<TbAp> selectTbApList(TbAp tbAp);

    /**
     * 新增ap
     * 
     * @param tbAp ap
     * @return 结果
     */
    public int insertTbAp(TbAp tbAp);

    /**
     * 修改ap
     * 
     * @param tbAp ap
     * @return 结果
     */
    public int updateTbAp(TbAp tbAp);

    /**
     * 批量删除ap
     * 
     * @param apIds 需要删除的ap主键集合
     * @return 结果
     */
    public int deleteTbApByApIds(Long[] apIds);

    /**
     * 删除ap信息
     * 
     * @param apId ap主键
     * @return 结果
     */
    public int deleteTbApByApId(Long apId);
}
