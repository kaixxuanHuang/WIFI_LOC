package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.common.config.RuoYiConfig;
import com.ruoyi.common.core.domain.model.LoginUser;
import com.ruoyi.common.utils.file.FileUploadUtils;
import com.ruoyi.common.utils.file.MimeTypeUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.TbMap;
import com.ruoyi.system.service.ITbMapService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.web.multipart.MultipartFile;

/**
 * mapController
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
@RestController
@RequestMapping("/system/map")
public class TbMapController extends BaseController
{
    @Autowired
    private ITbMapService tbMapService;

    /**
     * 查询map列表
     */
    @PreAuthorize("@ss.hasPermi('system:map:list')")
    @GetMapping("/list")
    public TableDataInfo list(TbMap tbMap)
    {
        startPage();
        List<TbMap> list = tbMapService.selectTbMapList(tbMap);
        return getDataTable(list);
    }

    /**
     * 导出map列表
     */
    @PreAuthorize("@ss.hasPermi('system:map:export')")
    @Log(title = "map", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TbMap tbMap)
    {
        List<TbMap> list = tbMapService.selectTbMapList(tbMap);
        ExcelUtil<TbMap> util = new ExcelUtil<TbMap>(TbMap.class);
        util.exportExcel(response, list, "map数据");
    }

    /**
     * 获取map详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:map:query')")
    @GetMapping(value = "/{mapId}")
    public AjaxResult getInfo(@PathVariable("mapId") Long mapId)
    {
        return success(tbMapService.selectTbMapByMapId(mapId));
    }

    /**
     * 新增map
     */
    @PreAuthorize("@ss.hasPermi('system:map:add')")
    @Log(title = "map", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TbMap tbMap)
    {
        return toAjax(tbMapService.insertTbMap(tbMap));
    }

    /**
     * 修改map
     */
    @PreAuthorize("@ss.hasPermi('system:map:edit')")
    @Log(title = "map", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TbMap tbMap)
    {
        return toAjax(tbMapService.updateTbMap(tbMap));
    }

    /**
     * 地图更新
     */
    @Log(title = "地图", businessType = BusinessType.UPDATE)
    @PostMapping("/upload/{mapId}")
    public AjaxResult avatar( MultipartFile file, @PathVariable Long mapId) throws Exception
    {
        if (!file.isEmpty())
        {
            String map = FileUploadUtils.upload(RuoYiConfig.getMapPath(), file, MimeTypeUtils.IMAGE_EXTENSION);
            TbMap tbMap = tbMapService.selectTbMapByMapId(mapId);
            tbMap.setMapUrl(map);
            return toAjax(tbMapService.updateTbMap(tbMap));
        }
        return error("上传地图异常，请联系管理员");
    }

    /**
     * 地图上传
     */
    @Log(title = "地图", businessType = BusinessType.UPDATE)
    @PostMapping("/upload/new/{mapId}")
    public AjaxResult avatarNew( @RequestParam("file")MultipartFile file, @PathVariable String mapId
            , @RequestParam("mapName") String mapName
            , @RequestParam("sceneId") Long sceneId
            , @RequestParam("mapX") Double mapX
            , @RequestParam("mapY") Double mapY) throws Exception
    {
        if (!file.isEmpty())
        {
            String map = FileUploadUtils.upload(RuoYiConfig.getMapPath(), file, MimeTypeUtils.IMAGE_EXTENSION);
            if(!mapId.equals("null")){
                TbMap tbMap = tbMapService.selectTbMapByMapId(Long.parseLong(mapId));
                tbMap.setMapUrl(map);
                return toAjax(tbMapService.updateTbMap(tbMap));
            }else{
                TbMap tbMap = new TbMap();
                tbMap.setSceneId(sceneId);
                tbMap.setMapName(mapName);
                tbMap.setMapX(mapX);
                tbMap.setMapY(mapY);
                tbMap.setMapUrl(map);
                return toAjax(tbMapService.insertTbMap(tbMap));
            }
        }
        return error("上传地图异常，请联系管理员");
    }

    /**
     * 删除map
     */
    @PreAuthorize("@ss.hasPermi('system:map:remove')")
    @Log(title = "map", businessType = BusinessType.DELETE)
	@DeleteMapping("/{mapIds}")
    public AjaxResult remove(@PathVariable Long[] mapIds)
    {
        return toAjax(tbMapService.deleteTbMapByMapIds(mapIds));
    }
}
