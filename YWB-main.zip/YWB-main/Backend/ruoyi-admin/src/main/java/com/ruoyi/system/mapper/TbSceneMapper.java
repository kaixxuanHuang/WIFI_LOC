package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.TbScene;

/**
 * scceneMapper接口
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
public interface TbSceneMapper 
{
    /**
     * 查询sccene
     * 
     * @param sceneId sccene主键
     * @return sccene
     */
    public TbScene selectTbSceneBySceneId(Long sceneId);

    /**
     * 查询sccene列表
     * 
     * @param tbScene sccene
     * @return sccene集合
     */
    public List<TbScene> selectTbSceneList(TbScene tbScene);

    /**
     * 新增sccene
     * 
     * @param tbScene sccene
     * @return 结果
     */
    public int insertTbScene(TbScene tbScene);

    /**
     * 修改sccene
     * 
     * @param tbScene sccene
     * @return 结果
     */
    public int updateTbScene(TbScene tbScene);

    /**
     * 删除sccene
     * 
     * @param sceneId sccene主键
     * @return 结果
     */
    public int deleteTbSceneBySceneId(Long sceneId);

    /**
     * 批量删除sccene
     * 
     * @param sceneIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTbSceneBySceneIds(Long[] sceneIds);
}
