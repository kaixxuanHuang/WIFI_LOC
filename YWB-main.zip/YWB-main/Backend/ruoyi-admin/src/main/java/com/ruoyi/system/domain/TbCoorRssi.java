package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 指纹库管理对象 tb_coor_rssi
 * 
 * @author ruoyi
 * @date 2023-02-21
 */
public class TbCoorRssi extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    private Long crId;

    /** wifi的坐标 */
    @Excel(name = "wifi的坐标")
    private String wifiapCoor;

    /** wifi指纹列表 */
    @Excel(name = "wifi指纹列表")
    private String wifiRssi;

    /** 场景编号 */
    @Excel(name = "场景编号")
    private Long sceneId;

    public void setCrId(Long crId) 
    {
        this.crId = crId;
    }

    public Long getCrId() 
    {
        return crId;
    }
    public void setWifiapCoor(String wifiapCoor) 
    {
        this.wifiapCoor = wifiapCoor;
    }

    public String getWifiapCoor() 
    {
        return wifiapCoor;
    }
    public void setWifiRssi(String wifiRssi) 
    {
        this.wifiRssi = wifiRssi;
    }

    public String getWifiRssi() 
    {
        return wifiRssi;
    }
    public void setSceneId(Long sceneId) 
    {
        this.sceneId = sceneId;
    }

    public Long getSceneId() 
    {
        return sceneId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("crId", getCrId())
            .append("wifiapCoor", getWifiapCoor())
            .append("wifiRssi", getWifiRssi())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("sceneId", getSceneId())
            .toString();
    }
}
