package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.TbSceneMapper;
import com.ruoyi.system.domain.TbScene;
import com.ruoyi.system.service.ITbSceneService;

/**
 * scceneService业务层处理
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
@Service
public class TbSceneServiceImpl implements ITbSceneService 
{
    @Autowired
    private TbSceneMapper tbSceneMapper;

    /**
     * 查询sccene
     * 
     * @param sceneId sccene主键
     * @return sccene
     */
    @Override
    public TbScene selectTbSceneBySceneId(Long sceneId)
    {
        return tbSceneMapper.selectTbSceneBySceneId(sceneId);
    }

    /**
     * 查询sccene列表
     * 
     * @param tbScene sccene
     * @return sccene
     */
    @Override
    public List<TbScene> selectTbSceneList(TbScene tbScene)
    {
        return tbSceneMapper.selectTbSceneList(tbScene);
    }

    /**
     * 新增sccene
     * 
     * @param tbScene sccene
     * @return 结果
     */
    @Override
    public int insertTbScene(TbScene tbScene)
    {
        tbScene.setCreateTime(DateUtils.getNowDate());
        return tbSceneMapper.insertTbScene(tbScene);
    }

    /**
     * 修改sccene
     * 
     * @param tbScene sccene
     * @return 结果
     */
    @Override
    public int updateTbScene(TbScene tbScene)
    {
        tbScene.setUpdateTime(DateUtils.getNowDate());
        return tbSceneMapper.updateTbScene(tbScene);
    }

    /**
     * 批量删除sccene
     * 
     * @param sceneIds 需要删除的sccene主键
     * @return 结果
     */
    @Override
    public int deleteTbSceneBySceneIds(Long[] sceneIds)
    {
        return tbSceneMapper.deleteTbSceneBySceneIds(sceneIds);
    }

    /**
     * 删除sccene信息
     * 
     * @param sceneId sccene主键
     * @return 结果
     */
    @Override
    public int deleteTbSceneBySceneId(Long sceneId)
    {
        return tbSceneMapper.deleteTbSceneBySceneId(sceneId);
    }
}
