package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.TbCoorRssi;

/**
 * 指纹库管理Mapper接口
 * 
 * @author ruoyi
 * @date 2023-02-21
 */
public interface TbCoorRssiMapper 
{
    /**
     * 查询指纹库管理
     * 
     * @param crId 指纹库管理主键
     * @return 指纹库管理
     */
    public TbCoorRssi selectTbCoorRssiByCrId(Long crId);

    /**
     * 查询指纹库管理列表
     * 
     * @param tbCoorRssi 指纹库管理
     * @return 指纹库管理集合
     */
    public List<TbCoorRssi> selectTbCoorRssiList(TbCoorRssi tbCoorRssi);

    /**
     * 新增指纹库管理
     * 
     * @param tbCoorRssi 指纹库管理
     * @return 结果
     */
    public int insertTbCoorRssi(TbCoorRssi tbCoorRssi);

    /**
     * 修改指纹库管理
     * 
     * @param tbCoorRssi 指纹库管理
     * @return 结果
     */
    public int updateTbCoorRssi(TbCoorRssi tbCoorRssi);

    /**
     * 删除指纹库管理
     * 
     * @param crId 指纹库管理主键
     * @return 结果
     */
    public int deleteTbCoorRssiByCrId(Long crId);

    /**
     * 批量删除指纹库管理
     * 
     * @param crIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTbCoorRssiByCrIds(Long[] crIds);
}
