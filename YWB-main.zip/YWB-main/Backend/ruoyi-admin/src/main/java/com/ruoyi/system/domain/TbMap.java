package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * map对象 tb_map
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
public class TbMap extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    @Excel(name = "编号")
    private Long mapId;

    /** 链接 */
    @Excel(name = "链接")
    private String mapUrl;

    /** x轴长度 */
    @Excel(name = "x轴长度")
    private Double mapX;

    /** y轴长度 */
    @Excel(name = "y轴长度")
    private Double mapY;

    /** 名称 */
    @Excel(name = "名称")
    private String mapName;

    /** 场景编号 */
    @Excel(name = "场景编号")
    private Long sceneId;

    public void setMapId(Long mapId) 
    {
        this.mapId = mapId;
    }

    public Long getMapId() 
    {
        return mapId;
    }
    public void setMapUrl(String mapUrl) 
    {
        this.mapUrl = mapUrl;
    }

    public String getMapUrl() 
    {
        return mapUrl;
    }
    public void setMapX(Double mapX)
    {
        this.mapX = mapX;
    }

    public Double getMapX()
    {
        return mapX;
    }
    public void setMapY(Double mapY)
    {
        this.mapY = mapY;
    }

    public Double getMapY()
    {
        return mapY;
    }
    public void setMapName(String mapName) 
    {
        this.mapName = mapName;
    }

    public String getMapName() 
    {
        return mapName;
    }
    public void setSceneId(Long sceneId) 
    {
        this.sceneId = sceneId;
    }

    public Long getSceneId() 
    {
        return sceneId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("mapId", getMapId())
            .append("mapUrl", getMapUrl())
            .append("mapX", getMapX())
            .append("mapY", getMapY())
            .append("mapName", getMapName())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("sceneId", getSceneId())
            .toString();
    }
}
