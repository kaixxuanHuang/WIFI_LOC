package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.TbMapMapper;
import com.ruoyi.system.domain.TbMap;
import com.ruoyi.system.service.ITbMapService;

/**
 * mapService业务层处理
 * 
 * @author ruoyi
 * @date 2022-11-28
 */
@Service
public class TbMapServiceImpl implements ITbMapService 
{
    @Autowired
    private TbMapMapper tbMapMapper;

    /**
     * 查询map
     * 
     * @param mapId map主键
     * @return map
     */
    @Override
    public TbMap selectTbMapByMapId(Long mapId)
    {
        return tbMapMapper.selectTbMapByMapId(mapId);
    }

    /**
     * 查询map列表
     * 
     * @param tbMap map
     * @return map
     */
    @Override
    public List<TbMap> selectTbMapList(TbMap tbMap)
    {
        return tbMapMapper.selectTbMapList(tbMap);
    }

    /**
     * 新增map
     * 
     * @param tbMap map
     * @return 结果
     */
    @Override
    public int insertTbMap(TbMap tbMap)
    {
        tbMap.setCreateTime(DateUtils.getNowDate());
        return tbMapMapper.insertTbMap(tbMap);
    }

    /**
     * 修改map
     * 
     * @param tbMap map
     * @return 结果
     */
    @Override
    public int updateTbMap(TbMap tbMap)
    {
        tbMap.setUpdateTime(DateUtils.getNowDate());
        return tbMapMapper.updateTbMap(tbMap);
    }

    /**
     * 批量删除map
     * 
     * @param mapIds 需要删除的map主键
     * @return 结果
     */
    @Override
    public int deleteTbMapByMapIds(Long[] mapIds)
    {
        return tbMapMapper.deleteTbMapByMapIds(mapIds);
    }

    /**
     * 删除map信息
     * 
     * @param mapId map主键
     * @return 结果
     */
    @Override
    public int deleteTbMapByMapId(Long mapId)
    {
        return tbMapMapper.deleteTbMapByMapId(mapId);
    }
}
