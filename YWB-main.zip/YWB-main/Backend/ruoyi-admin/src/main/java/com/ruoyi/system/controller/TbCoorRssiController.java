package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.TbCoorRssi;
import com.ruoyi.system.service.ITbCoorRssiService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 指纹库管理Controller
 * 
 * @author ruoyi
 * @date 2023-02-21
 */
@RestController
@RequestMapping("/system/rssi")
public class TbCoorRssiController extends BaseController
{
    @Autowired
    private ITbCoorRssiService tbCoorRssiService;

    /**
     * 查询指纹库管理列表
     */
    @PreAuthorize("@ss.hasPermi('system:rssi:list')")
    @GetMapping("/list")
    public TableDataInfo list(TbCoorRssi tbCoorRssi)
    {
        startPage();
        List<TbCoorRssi> list = tbCoorRssiService.selectTbCoorRssiList(tbCoorRssi);
        return getDataTable(list);
    }

    /**
     * 导出指纹库管理列表
     */
    @PreAuthorize("@ss.hasPermi('system:rssi:export')")
    @Log(title = "指纹库管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TbCoorRssi tbCoorRssi)
    {
        List<TbCoorRssi> list = tbCoorRssiService.selectTbCoorRssiList(tbCoorRssi);
        ExcelUtil<TbCoorRssi> util = new ExcelUtil<TbCoorRssi>(TbCoorRssi.class);
        util.exportExcel(response, list, "指纹库管理数据");
    }

    /**
     * 获取指纹库管理详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:rssi:query')")
    @GetMapping(value = "/{crId}")
    public AjaxResult getInfo(@PathVariable("crId") Long crId)
    {
        return success(tbCoorRssiService.selectTbCoorRssiByCrId(crId));
    }

    /**
     * 新增指纹库管理
     */
    @PreAuthorize("@ss.hasPermi('system:rssi:add')")
    @Log(title = "指纹库管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TbCoorRssi tbCoorRssi)
    {
        return toAjax(tbCoorRssiService.insertTbCoorRssi(tbCoorRssi));
    }

    /**
     * 修改指纹库管理
     */
    @PreAuthorize("@ss.hasPermi('system:rssi:edit')")
    @Log(title = "指纹库管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TbCoorRssi tbCoorRssi)
    {
        return toAjax(tbCoorRssiService.updateTbCoorRssi(tbCoorRssi));
    }

    /**
     * 删除指纹库管理
     */
    @PreAuthorize("@ss.hasPermi('system:rssi:remove')")
    @Log(title = "指纹库管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{crIds}")
    public AjaxResult remove(@PathVariable Long[] crIds)
    {
        return toAjax(tbCoorRssiService.deleteTbCoorRssiByCrIds(crIds));
    }
}
