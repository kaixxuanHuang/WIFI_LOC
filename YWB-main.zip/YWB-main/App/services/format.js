export const formatDateTime = (date, type) => {
	if (!date) {
		return ''
	}
	let newDate = new Date(date)
	let {
		y,
		M,
		d,
		h,
		m,
		s
	} = {
		y: newDate.getFullYear(),
		M: newDate.getMonth() + 1,
		d: newDate.getDate(),
		h: newDate.getHours(),
		m: newDate.getMinutes(),
		s: newDate.getSeconds()
	}
	M = M < 10 ? '0' + M : M
	d = d < 10 ? '0' + d : d
	h = h < 10 ? '0' + h : h
	m = m < 10 ? '0' + m : m
	s = s < 10 ? '0' + s : s
	if (type === 'YYYY-MM') {
		return `${y}-${M}`
	}
	if (type === 'hh:mm') {
		return `${h}:${m}`
	}
	if (type === 'YYYY-MM-DD HH:mm:ss') {
		return `${y}-${M}-${d} ${h}:${m}:${s}`
	}
	if (type === 'YYYY-MM-DD HH') {
		return `${y}-${M}-${d} ${h}`
	}
	if (type === 'YYYY-MM-DD') {
		return `${y}-${M}-${d}`
	}
	if (type === 'YYYYMMDD') {
		return `${y}${M}${d}`
	}
	if (type === 'YYYY') {
		return `${y}`
	}
	if (type === 'MM-DD') {
		return `${M}-${d}`
	}
	if (type === 'hh:mm:ss') {
		return `${h}:${m}:${s}`
	}
	return `${y}-${M}-${d} ${h}:${m}:${s}`
}
