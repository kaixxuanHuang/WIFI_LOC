import ajax from 'uni-ajax'
import store from '@/store'

// 创建请求实例
const instance = ajax.create({
	// 初始配置
	baseURL: store.state.url
	// baseURL: 'http://47.96.139.212:8088'
})

// 添加请求拦截器
instance.interceptors.request.use(
	config => {
		// 在发送请求前做些什么
		const {
			url
		} = config
		if (!(url.startsWith('/login') ||
				url.startsWith('/captchaImage'))) {
			var token = store.state.token
			if (token) config.header.Authorization = 'Bearer ' + token
			else {
				// 未登录的话返回登录页面
				uni.showToast({
					title: "登录失效，请重新登录",
					icon: "error"
				});
				uni.reLaunch({
					url: '/pages/login/login'
				})
			}
		}
		return config
	},
	error => {
		// 对请求错误做些什么
		return Promise.reject(error)
	}
)

// 添加响应拦截器
instance.interceptors.response.use(
	response => {
		// 对响应数据做些什么
		const {
			code,
			msg
		} = response.data
		if (code === 403) {
			uni.showToast({
				title: "登录过期，重新登录",
				icon: "error"
			});
			store.state.token = null
			uni.reLaunch({
				url: '/pages/login/login'
			})
		}
		if (code === 401) {
			uni.showToast({
				title: "认证失败，重新登录",
				icon: "error"
			});
			store.state.token = null
			uni.reLaunch({
				url: '/pages/login/login'
			})
		}
		if (code === 500) {
			uni.showToast({
				title: msg,
				icon: "error"
			});
		}
		return response
	},
	error => {
		// 对响应错误做些什么
		return Promise.reject(error)
	}
)

// 导出 create 创建后的实例
export default instance
