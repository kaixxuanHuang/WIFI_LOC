<template>
	<view class="loc-container" :style="'height:'+this.imagePos.height+250+'px;'">
		<image class="loc-map" :src='img_path' mode="widthFix"></image>
		<canvas canvas-id="myCanvas" :style="'height:'+this.imagePos.height+'px;'+'width:730rpx'" v-if="appMode!==3" />
		<movable-area class="loc-data-movable" :style="'height:'+this.imagePos.height+'px;'" v-if="appMode===3">
			<movable-view class="loc-data-item" :x="data.x/mapRate" :y="data.y/mapRate" direction="all"
				animation="false" @change="onLocChanged($event, data)" @touchend="onLocTouchend(data)"
				v-for="(data, index) in locDataList" @longpress="openLocDataDialogDel(data)" v-if="appMode===3">
				<uni-icons class='footer-icon' type="location-filled" :color="data.color" size="40"
					@click="openLocDataDialog(data)">
				</uni-icons>
			</movable-view>
		</movable-area>
		<!-- 采集对话框 -->
		<uni-popup ref="locDataAlertDialog" type="dialog">
			<uni-popup-dialog type="success" cancelText="取消" confirmText="采集" title="数据采集" :content="locDataDialogText"
				@confirm.once="locDataDialogConfirm" @close="locDataDialogClose"></uni-popup-dialog>
		</uni-popup>
		<!-- 删除对话框 -->
		<uni-popup ref="locDataAlertDialogDel" type="dialog">
			<uni-popup-dialog type="warning" cancelText="取消" confirmText="删除" title="是否删除选中数据"
				@confirm.once="locDataDialogDel"></uni-popup-dialog>
		</uni-popup>
		<!-- 清空对话框 -->
		<uni-popup ref="locDataAlertDialogClear" type="dialog">
			<uni-popup-dialog type="warning" cancelText="取消" confirmText="清空" title="是否清空场景数据"
				@confirm.once="locDataDialogClear"></uni-popup-dialog>
		</uni-popup>
		<!-- 顶部信息提示栏 -->
		<view>
			<uni-popup ref="dataMessage" type="message">
				<uni-popup-message :type="msgType" :message="messageText" :duration="3000"></uni-popup-message>
			</uni-popup>
		</view>
		<!-- 添加位置悬浮按钮 -->
		<uni-fab v-if="appMode===3" :popMenu="true" :content="locDataContent" :pattern="locDataPattern"
			@trigger="locDataTrigger" @fabClick="tapLocDataFab" horizontal="left"></uni-fab>
	</view>
	<uni-drawer ref="leftDraw" mode="left" :width="330" @change="changeDraw($event)">
		<scroll-view class="draw-scroll-view" scroll-y>
			<uni-section title="状态切换" type="line">
				<view class="app-mode-container" style="padding: 5px 15px;">
					<view>
						<uni-data-checkbox mode="tag" v-model="appMode" @change="changeAppMode()"
							:localdata="appModeList">
						</uni-data-checkbox>
					</view>
				</view>
			</uni-section>
			<uni-section title="场景选择" type="line">
				<view class="scene-container" style="padding: 5px 15px;">
					<uni-data-select v-model="scene" :localdata="sceneRange" @change="changeScene" :clear="false">
					</uni-data-select>
				</view>
			</uni-section>

			<uni-section title="AP设置" type="line">
				<view class="section-body">
					<span class="ap-buttons">
						<button size="mini" type="primary" @click="addAp()"><text class="word-btn-white">添加ap</text>
						</button>
					</span>
					<uni-popup ref="ApDialog" type="dialog">
						<uni-popup-dialog ref="ApClose" :title="apFormType==='add'?'新增Ap':'编辑Ap'" before-close
							@close="closeApDialog()" @confirm="submitAp('apForm')">
							<uni-forms ref="apForm" :modelValue="apFormData" labelWidth="80px" :rules="ApRules">
								<uni-forms-item label="Mac地址" name="apMac" required>
									<uni-easyinput v-model="apFormData.apMac" placeholder="请输入Mac地址" />
								</uni-forms-item>
								<uni-forms-item label="x轴坐标" name="apX" required>
									<uni-easyinput v-model="apFormData.apX" placeholder="请输入x轴坐标" />
								</uni-forms-item>
								<uni-forms-item label="y轴坐标" name="apY" required>
									<uni-easyinput v-model="apFormData.apY" placeholder="请输入y轴坐标" />
								</uni-forms-item>
								<!-- <button type="primary" @click="submitAp('apForm')">提交AP</button> -->
							</uni-forms>
						</uni-popup-dialog>
					</uni-popup>
					<!-- AP列表 -->
					<uni-collapse>
						<uni-collapse-item title="AP列表" show-animationo :open="isCollapse" v-if="APList">
							<uni-list>
								<uni-list-item :title="item.apMac" :note="'x: '+item.apX +' &nbsp;&nbsp; y: '+item.apY"
									v-for="item in APList">
									<template v-slot:header>
										<view class="slot-box">
											<image class="slot-image" src="/static/map_icon/ap.png" mode="widthFix">
											</image>
										</view>
									</template>
									<template v-slot:footer>
										<span class="AP-list-footer">
											<uni-icons class='footer-icon' type="compose" color="#1296db" size="20"
												@click="editAp(item)">
											</uni-icons>
											<uni-icons class='footer-icon' type="trash-filled" color="#d81e06" size="20"
												@click="delAp(item)"></uni-icons>
										</span>
									</template>
								</uni-list-item>
							</uni-list>
						</uni-collapse-item>
					</uni-collapse>
				</view>
			</uni-section>
			<uni-section title="地图" type="line">
				<view class="section-body" v-if="img_path_chose">
					<view class="section-form" v-if="mapFormData">
						<uni-forms ref="mapForm" :modelValue="mapFormData" labelWidth="80px" :rules="mapRules">
							<uni-forms-item label="地图" name="map" required>
								<image class="section-map" :src="img_path_chose" @click="chooseMap"></image>
							</uni-forms-item>
							<uni-forms-item label="x轴长度" name="mapX" required>
								<uni-easyinput v-model="mapFormData.mapX" placeholder="x轴长度" />
							</uni-forms-item>
							<uni-forms-item label="y轴长度" name="mapY" required>
								<uni-easyinput v-model="mapFormData.mapY" placeholder="y轴长度" />
							</uni-forms-item>
							<button type="primary" @click="submitMap('mapForm')">提交地图</button>
						</uni-forms>
					</view>
				</view>
			</uni-section>
		</scroll-view>
	</uni-drawer>
</template>

<script>
	import locjs from './loc.js'
	export default {
		...locjs,
	}
</script>

<style lang="scss">
	@import './loc.scss'
</style>
