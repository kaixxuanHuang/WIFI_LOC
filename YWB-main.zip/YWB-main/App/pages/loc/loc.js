import {
	mapMutations,
	mapGetters,
	mapState
} from 'vuex'

// 画布
var ctx = null
var location_offline = -1
export default {
	name: 'locjsname',
	data() {

		return {
			// 是否展开折叠栏
			isCollapse: true,
			// 是否显示抽屉
			isDrawer: false,
			// 画布上圆形的半径
			radis: 15,
			// 打开表单的方式
			apFormType: 'add',
			// app所处的状态列表
			appModeList: [{
				text: '开启定位',
				value: 1
			}, {
				text: '定位设置',
				value: 2
			}, {
				text: '采集数据',
				value: 3
			}],
			// 当前状态 默认进入时显示AP
			appMode: 2,
			// 场景列表
			sceneList: [],
			sceneRange: [],
			// 是否显示ap表单
			isApForm: false,
			// AP表单
			apFormData: {
				apMac: null,
				apX: null,
				apY: null
			},
			// AP列表
			APList: [],
			ApRules: {
				apMac: {
					rules: [{
						required: true,
						errorMessage: 'Mac不能为空'
					}]
				},
				apX: {
					rules: [{
						required: true,
						errorMessage: 'x坐标不能为空'
					}]
				},
				apY: {
					rules: [{
						required: true,
						errorMessage: 'y坐标不能为空'
					}]
				},
			},
			// 采集数据部分变量————————————————————————————
			// 提示信息内容
			msgType: 'success',
			messageText: '',
			// 采集数据列表
			locDataList: [],
			// 按钮是否显示
			locDataBoolean: false,
			locDataContent: [],
			// 当前移动的点的位置
			locDataTemp: null,
			locDataPattern: {
				buttonColor: '#007AFF',
				iconColor: '#fff'
			},
			// 采集窗口内文字信息
			locDataDialogText: '',
			// 当前被选中的坐标点变量
			locDataCurrent: null,
			// 地图相关变量————————————————————————————————————
			// 地图在服务器上的路径
			img_path: '',
			// 显示出来的图片宽高
			imagePos: {},
			// 地图比例，暂时计算方式为x和y轴的比例平均
			mapRate: 1,
			mapFormData: {
				mapX: null,
				mapY: null,
				mapUrl: null
			},
			mapRules: {
				mapX: {
					rules: [{
						required: true,
						errorMessage: 'x轴长度不能为空'
					}]
				},
				mapY: {
					rules: [{
						required: true,
						errorMessage: 'y轴长度不能为空'
					}]
				}
			},
			// 当前连接wifi的信息
			connectWifiInfo: {},
			// 存了wifi列表的BSSID和RSSI
			wifiList: [],
			// 陀螺仪数据 degree, x, y, z
			Gyroscope_data: {},
			// 罗盘
			Compass_data: {},
			// 加速计
			Accelerometer_data: {},
			// 设备传感器定时器0.5s
			timeInter0_5: null,
			// wifi列表定时器5s
			timeInter5: null,
		}
	},
	computed: mapState([
		'scene', 'userInfo', 'url'
	]),
	created() {
		// 初始化画布对象
		ctx = uni.createCanvasContext("myCanvas")
		// 获取场景列表
		this.getSceneList()
		// 获取wifi需要定位权限
		uni.getLocation()
	},
	// 页面隐藏后删除定时器
	onHide() {
		this.clearAllInternal()
	},
	// 页面加载后设置定时器，获取定位信息
	onShow() {
		if (this.appMode === 1)
			// 设置获取信息的定时器
			this.setTimeInterval()
	},
	// 右上角菜单被点击后
	onNavigationBarButtonTap(obj) {
		if (obj.type === 'menu') {
			if (this.isDrawer) {
				this.$refs['leftDraw'].close()
			} else {
				this.$refs['leftDraw'].open()
			}
			this.isDrawer = !this.isDrawer
			this.getMapInfo()
		}
	},
	methods: {
		...mapMutations([
			'setScene'
		]),
		...mapGetters([
			'getScene', 'getToken'
		]),
		// ——————————————————————————当前模式相关方法———1：定位——————2：设置———————————————————
		// 切换模式
		changeAppMode(mode) {
			if (mode) {
				this.appMode = mode
				return
			}
			// 切换到显示Ap模式
			if (this.appMode === 2) {
				this.clearAllInternal()
				this.getAPList()
				this.isCollapse = true
			} else if (this.appMode === 1) {
				this.clearDraw()
				this.setTimeInterval()
				this.isCollapse = false
				// 切换定位后重置rssi库
				this.getLocDataList()
			} else if (this.appMode === 3) {
				// 选择采集数据模式后重置状态
				this.clearDraw()
				this.clearAllInternal()
				// this.setTimeInterval()
				this.isCollapse = false
				this.$refs.leftDraw.close();
				this.locDataContent= [
					{
						iconPath: '/static/point.png',
						selectedIconPath: '/static/point-slt.png',
						text: '选点',
						active: false
					},
					{
						iconPath: '/static/clearall.png',
						text: '清空',
						active: false
					},
					{
						iconPath: '/static/refresh.png',
						text: '刷新',
						active: false
					}
				],
				this.getLocDataList()
				this.msgType = 'success'
				this.messageText = `单击图标采集数据 长按图标删除数据 拖动图标选择位置`
				this.$refs.dataMessage.open()
			}
		},
		// ————————————————————————————————场景相关函数————————————————————————————————
		// 获取场景列表，没有缓存时默认显示第一个场景
		getSceneList() {
			uni.$ajax({
				url: '/system/scene/list',
				method: 'get',
				data: {
					pageNum: 1,
					pageSize: 100
				}
			}).then(res => {
				var res = res.data
				this.sceneRange = []
				if (res.rows)
					res.rows.forEach(s => {
						var scene = {
							value: s.sceneId,
							text: s.sceneName
						}
						this.sceneRange.push(scene)
						if (this.sceneRange.length > 0) {
							if (this.scene == undefined) this.setScene(this.sceneRange[0].value)
							// 获取地图
							this.getMapInfo()
						}
					})
			})
		},
		// 切换场景
		changeScene(e) {
			// 更新缓存中的场景
			this.setScene(e)
			// 获取地图
			this.getMapInfo()
		},
		// ————————————————————————————————————地图相关函数————————————————————————————————
		// 获取地图
		getMapInfo() {
			this.mapFormData = null
			uni.$ajax({
				url: '/system/map/list',
				method: 'get',
				data: {
					pageNum: 1,
					pageSize: 100,
					sceneId: this.scene
				}
			}).then(res => {
				var res = res.data
				if (res.rows && res.rows.length > 0) {
					this.mapFormData = res.rows[0]
					this.img_path = this.url + this.mapFormData.mapUrl
					this.setCanvasHeight()
				} else {
					this.img_path = null
				}
				this.img_path_chose = this.img_path
				// 获取aplist
				this.getAPList()
			})
		},
		// 抽屉状态发生变化触发
		changeDraw(e) {
			this.isDrawer = e
		},
		// 从服务器获取AP列表
		getAPList() {
			this.APList = null
			uni.$ajax({
				url: '/system/ap/list',
				method: 'get',
				data: {
					pageNum: 1,
					pageSize: 100,
					sceneId: this.scene
				}
			}).then(res => {
				var res = res.data
				this.APList = res.rows
				setTimeout(res => {
					this.doApDraw(this.APList)
				}, 500)
			})
		},
		addAp() {
			this.$refs.ApDialog.open()
			this.isApForm = !this.isApForm
			if (this.isApForm) this.apFormType = 'add'
			this.apFormData = {
				apMac: null,
				apX: null,
				apY: null,
				sceneId: this.scene
			}
		},
		editAp(ap) {
			this.$refs.ApDialog.open()
			this.isApForm = true
			this.apFormType = 'edit'
			this.apFormData = {
				...ap
			}
		},
		delAp(ap) {
			uni.$ajax({
				url: '/system/ap/' + ap.apId,
				method: 'delete'
			}).then(res => {
				this.getAPList()
				uni.showToast({
					title: '删除AP成功'
				});
			})
		},
		// 提交Ap参数
		submitAp(ref) {
			this.$refs[ref].validate().then(res => {
				if (this.apFormType === 'add') {
					uni.$ajax({
						url: '/system/ap',
						method: 'post',
						data: this.apFormData
					}).then(res => {
						var res = res.data
						uni.showToast({
							title: '添加AP成功'
						});
						this.getAPList()
					})

				} else if (this.apFormType === 'edit') {
					uni.$ajax({
						url: '/system/ap',
						method: 'put',
						data: this.apFormData
					}).then(res => {
						var res = res.data
						uni.showToast({
							title: '编辑AP成功'
						});
					})
				}
				this.closeApDialog()
				this.getAPList()
			})
		},
		// 关闭Ap对话框
		closeApDialog() {
			this.$refs.ApDialog.close()
		},
		// ————————————————————————采集数据方法——————————————————————————————
		// 从服务器获取已采样的数据,因为图标原因需要坐标修正
		getLocDataList() {
			// this.locDataList = [{id:1, x:10,y:12,color:'#1296db'} , {id:2,x:15,y:17,color:'#1296db'}]
			uni.$ajax({
				url: '/system/rssi/list',
				method: 'get',
				data: {
					pageNum: 1,
					pageSize: 100,
					sceneId: this.scene
				}
			}).then(res => {
				var locDataList = []
				var res = res.data
				res.rows.forEach(l => {
					var ld = {}
					ld.id = l.crId
					ld.x = l.wifiapCoor.split(' ')[0] - 10 * this.mapRate
					ld.y = l.wifiapCoor.split(' ')[1] - 20 * this.mapRate
					ld.wifiRssi = l.wifiRssi
					ld.color = '#1296db'
					locDataList.push(ld)
				})
				this.locDataList = locDataList
				// console.log(this.locDataList);
			})
		},
		// 获取数据点最新位置
		onLocChanged(e, data) {
			this.locDataTemp = {
				id: data.id,
				x: (e.detail.x) * this.mapRate,
				y: (e.detail.y) * this.mapRate
			}
		},
		// 图标移动结束后
		onLocTouchend(data) {
			// 移动的是新增的点
			if (data.id === -1) {
				// 修改坐标
				if (this.locDataTemp && this.locDataTemp.id === data.id) {
					this.locDataList[this.locDataList.length - 1].x = this.locDataTemp.x
					this.locDataList[this.locDataList.length - 1].y = this.locDataTemp.y
				}
			} else { //移动的是已存在的点
				// 正在新增点的时候移动了其他的点,则删除新增点
				// if(this.locDataBoolean){
				// 	this.locDataList.pop()
				// 	this.locDataBoolean = false
				// }
				// 查询被选择的点
				var index = this.locDataList.findIndex(item => item.id === data.id)
				if (index === -1) return
				this.locDataList[index].color = '#d81e06'
				// 坐标修正
				if (this.locDataTemp && this.locDataTemp.id === data.id) {
					this.locDataList[index].x = this.locDataTemp.x
					this.locDataList[index].y = this.locDataTemp.y
				}
				this.msgType = 'warn'
				this.messageText = `单击图标重新采集数据 采集完成后图标显示蓝色`
				this.$refs.dataMessage.open()
			}
			// console.log(this.locDataList);
		},
		// 点击新增点
		tapLocDataFab() {
			// this.locDataBoolean = true
			// this.locDataList.push({
			// 	id: -1,
			// 	x: (this.imagePos.width / 2 - 20) * this.mapRate,
			// 	y: (this.imagePos.height / 2 - 20) * this.mapRate,
			// 	color: '#d81e06'
			// })
			this.msgType = 'warn'
			this.messageText = `单击图标采集数据 采集完成后图标显示蓝色`
			this.$refs.dataMessage.open()
		},
		// 选择悬浮按钮内部按钮后：新增/取消点 清空当前场景所有数据
		locDataTrigger(e) {
			// 选点
			if (e.index === 0) {
				this.locDataContent[e.index].active = !e.item.active
				if (this.locDataContent[e.index].active) {
					this.locDataContent[e.index].text = '取消'
					this.locDataList.push({
						id: -1,
						x: (this.imagePos.width / 2 - 20) * this.mapRate,
						y: (this.imagePos.height / 2 - 20) * this.mapRate,
						color: '#d81e06'
					})
				} else {
					this.locDataContent[e.index].text = '选点'
					this.locDataList.pop()
				}
			// 清空
			} else if (e.index === 1){
				this.openLocDataDialogClear()
			// 刷新
			}else if (e.index === 2){
				this.locDataContent[0].text = '选点'
				this.locDataContent[0].active = false
				this.getLocDataList()
			}
		},
		// 打开数据收集弹窗
		openLocDataDialog(data) {
			this.$refs.locDataAlertDialog.open()
			this.locDataDialogText = '当前选择点的坐标为x：' +
				(data.x / this.mapRate).toFixed(2) + '\t \ty：' + (data.y / this.mapRate).toFixed(2) + '\n' +
				'数据为：' + data.wifiRssi
			// 保存当前弹出窗口的选中点
			this.locDataCurrent = data
		},
		// 打开删除坐标点的对话框
		openLocDataDialogDel(data) {
			this.$refs.locDataAlertDialogDel.open()
			// 保存当前弹出窗口的选中点
			this.locDataCurrent = data
		},
		// 删除坐标点
		locDataDialogDel() {
			if (this.locDataBoolean) {
				this.locDataList.pop()
				this.locDataBoolean = false
			} else {
				uni.$ajax({
					url: '/system/rssi/' + this.locDataCurrent.id,
					method: 'delete'
				}).then(res => {
					this.locDataList = null
					this.getLocDataList()
					uni.showToast({
						title: '删除数据成功'
					});
				})
			}
		},
		// 打开清空坐标点的对话框
		openLocDataDialogClear(data) {
			this.$refs.locDataAlertDialogClear.open()
		},
		// 清空坐标点
		locDataDialogClear() {
			var locIds = []
			this.locDataList.forEach(ld =>{
				locIds.push(ld.id)
			})
			console.log(locIds);
			uni.$ajax({
				url: '/system/rssi/' + locIds.toString(),
				method: 'delete'
			}).then(res => {
				this.locDataList = null
				this.getLocDataList()
				uni.showToast({
					title: '清空数据成功'
				});
			})
		},
		// 开始采集数据
		locDataDialogConfirm() {
			this.getScanedWiFi()
			// 暂时重复写一段代码，用于数据处理
			var ap_len = this.APList.length //APList长度
			var wifi_len = this.wifiList.length //wifiList长度
			if (wifi_len > 10)
				var search_len = 10
			else
				var search_len = wifi_len //wifi搜索长度长度

			var wifi_rssi = new Array(ap_len).fill(-100) //全0数据存放wifi指纹

			for (var ap_index = 0; ap_index < ap_len; ap_index++) {
				for (var wifi_index = 1; wifi_index < search_len; wifi_index++) {
					var index = wifi_len - wifi_index
					if (this.wifiList[index].BSSID == this.APList[ap_index].apMac) {
						wifi_rssi[ap_index] = this.wifiList[index].level
					}
				}
			}
			var wifi_rssi_str = wifi_rssi.join(' ')
			// 实际坐标修正
			var locData = {
				wifiapCoor: (this.locDataCurrent.x + 10 * this.mapRate).toString() + ' ' + (this.locDataCurrent.y +
					20 * this.mapRate).toString(),
				wifiRssi: wifi_rssi_str,
				sceneId: this.scene
			}
			if (this.locDataCurrent.id === -1) {
				// 新增采集到的数据
				uni.$ajax({
					url: '/system/rssi/',
					method: 'post',
					data: locData
				}).then(res => {
					uni.showToast({
						title: '数据采集完成!'
					});
					// 修改坐标点颜色
					var index = this.locDataList.findIndex(item => item.id === this.locDataCurrent.id)
					this.locDataCurrent.id = 0
					if (index === -1) return
					this.locDataList[index].color = '#1296db'
					this.locDataBoolean = false
					this.locDataContent[0].active = false
					this.locDataContent[0].text = '选点'
				})
			} else {
				locData.crId = this.locDataCurrent.id
				// 编辑采集到的数据
				uni.$ajax({
					url: '/system/rssi/',
					method: 'put',
					data: locData
				}).then(res => {
					uni.showToast({
						title: '数据采集完成!'
					});
					// 修改坐标点颜色
					var index = this.locDataList.findIndex(item => item.id === this.locDataCurrent.id)
					if (index === -1) return
					this.locDataList[index].color = '#1296db'
				})
			}
			// this.getLocDataList()
		},
		// 取消采集数据
		locDataDialogClose() {},
		// ————————————————————————地图相关方法————————————————————————————
		// 从相册选择地图
		chooseMap() {
			uni.chooseImage({
				count: 1,
				sizeType: ['original'],
				sourceType: ['album'],
				success: (res) => {
					this.img_path_chose = null
					this.img_path_chose = res.tempFilePaths[0]
				}
			})
		},
		// 提交地图和地图比例
		submitMap(ref) {
			this.$refs[ref].validate().then(res => {
				uni.uploadFile({
					url: this.url + '/system/map/upload/' + this.mapFormData.mapId,
					header: {
						'Authorization': 'Bearer ' + this.getToken()
					},
					filePath: this.img_path_chose,
					success: (res) => {
						uni.showToast({
							title: '提交地图成功'
						})
					}
				})
				uni.$ajax({
					url: '/system/map',
					method: 'put',
					data: this.mapFormData
				}).then(res => {
					// console.log(res);
				})
				this.img_path = this.img_path_chose
				this.setCanvasHeight()
			})
		},

		// ————————————————————————定时器相关方法————————————————————————————————
		setTimeInterval() {
			var that = this
			var acc = []

			function getSensorData() {
				that.getLocationOffline()
				var res = that.Accelerometer_data
				var acc_flag = 100 * Math.sqrt(Math.pow(res.x, 2) + Math.pow(res.y, 2) + Math.pow(res.z + 1, 2))
				acc.push(acc_flag)

				if (acc.length == 10) {
					var max_index = 0
					var min_index = 0
					var max = acc[0]
					var min = acc[0]
					for (var i = 1; i < acc.length; i++) {
						if (acc[i] > max) {
							max = acc[i]
							max_index = i
						}
						if (acc[i] < min) {
							min = acc[i]
							min_index = i
						}
					}
					if (Math.abs(max_index - min_index) > 3 & Math.abs(max - min) > 12) {
						if (location_offline != -1 & location_offline != null) {
							var OfflineLoc_f = that.OfflineLoc_fusion(location_offline)
							console.log('PDR定位: ', JSON.stringify(OfflineLoc_f))
							that.doUserDraw(OfflineLoc_f[0], OfflineLoc_f[1], that.Compass_data)

						} else {
							console.log('无初始位置!')
						}
					} else {
						console.log('PDR定位检测到不是一个步态!')
					}
					acc.splice(0, acc.length)
				}
				//console.log('wifi', JSON.stringify(that.connectWifiInfo))
				//console.log('陀螺仪', JSON.stringify(that.Gyroscope_data))
				//console.log('罗盘', JSON.stringify(that.Compass_data))
				//console.log('加速器', JSON.stringify(that.Accelerometer_data))
				return getSensorData
			}
			// 获取设备传感器信息
			// 因为一直在断开wifi，连接wifi的信息偶尔会为null
			this.timeInter0_5 = setInterval(getSensorData(), 100)

			function getWifiList() {
				// #ifdef APP-PLUS
				that.getScanedWiFi()
				//console.log('wifiList', JSON.stringify(that.wifiList))
				// #endif
				var location = that.OfflineLoc_rssi()
				if (location != -1) {
					location_offline = location
					that.doUserDraw(location[0], location[1], that.Compass_data)
					//console.log('WIFI定位:', JSON.stringify(location),JSON.stringify(location_offline))

				} else {
					that.doUserDraw(0, 0, that.Compass_data)
					console.log('WIFI定位失败!')

				}


				return getWifiList
			}
			this.timeInter5 = setInterval(getWifiList(), 5000)
		},
		// 清除所有定时器
		clearAllInternal() {
			clearInterval(this.timeInter0_5)
			clearInterval(this.timeInter5)
		},

		//---------------------------------------离线定位部分----------------------------------------------------------------
		OfflineLoc_rssi() {
			var that = this

			var ap_len = that.APList.length //APList长度
			var wifi_len = that.wifiList.length //wifiList长度
			if (wifi_len > 10)
				var search_len = 10
			else
				var search_len = wifi_len //wifi搜索长度长度


			var wifi_rssi = new Array(ap_len).fill(-100) //全0数据存放wifi指纹
			var ble_rssi = new Array(1).fill(-100) //全0数据存放蓝牙指纹，不知蓝牙信标数量设为20
			var wifiap_coor = new Array(ap_len).fill(0).map(item => new Array(2).fill(0)) //存放wifi的坐标
			var bleap_coor = new Array(1).fill(0).map(item => new Array(2).fill(0)) //存放蓝牙的坐标


			for (var ap_index = 0; ap_index < ap_len; ap_index++) {
				wifiap_coor[ap_index][0] = that.APList[ap_index].apX
				wifiap_coor[ap_index][1] = that.APList[ap_index].apY
				for (var wifi_index = 1; wifi_index < search_len; wifi_index++) {
					var index = wifi_len - wifi_index
					if (that.wifiList[index].BSSID == that.APList[ap_index].apMac) {
						wifi_rssi[ap_index] = that.wifiList[index].level
					}
				}
			}


			if (wifi_rssi.length < 4) var wifiLoc = -1
			else {
				wifi_rssi,
				wifiap_coor = that.ss(wifi_rssi, wifiap_coor)
				var max_index = wifi_rssi.length - 1
				if (wifi_rssi[max_index - 3] == -100) var wifiLoc = -1
				else {
					var wifi_rssi_max4 = [wifi_rssi[max_index], wifi_rssi[max_index - 1], wifi_rssi[max_index - 2],
						wifi_rssi[max_index - 3]
					]
					var wifiap_coor_max4 = [wifiap_coor[max_index], wifiap_coor[max_index - 1], wifiap_coor[max_index -
						2], wifiap_coor[max_index - 3]]
					var wifi_dis = [0, 0, 0, 0]
					for (var i = 0; i < wifi_rssi_max4.length; i++) wifi_dis[i] = Math.pow(10, (-30 - wifi_rssi_max4[
						i]) / (10 * 3))
					var wifiLoc = that.ls(wifiap_coor_max4, wifi_dis)
				}
			}

			if (ble_rssi.length < 4) var bleLoc = -1
			else {
				ble_rssi,
				bleap_coor = that.ss(ble_rssi, bleap_coor)
				var max_index = ble_rssi.length - 1
				if (ble_rssi[max_index - 3] == -100) var bleLoc = -1
				else {
					var ble_rssi_max4 = [ble_rssi[max_index], ble_rssi[max_index - 1], ble_rssi[max_index - 2],
						ble_rssi[max_index - 3]
					]
					var bleap_coor_max4 = [bleap_coor[max_index], bleap_coor[max_index - 1], bleap_coor[max_index - 2],
						bleap_coor[max_index - 3]
					]

					var ble_dis = [0, 0, 0, 0]
					for (var i = 0; i < ble_rssi_max4.length; i++) ble_dis[i] = Math.pow(10, (-30 - ble_rssi_max4[i]) /
						(10 * 3))
					var bleLoc = that.ls(bleap_coor_max4, ble_dis)
				}
			}
			if (wifiLoc == -1 && bleLoc == -1) return -1
			else if (wifiLoc == -1) return bleLoc
			else if (bleLoc == -1) return wifiLoc
			else return [0.5 * (wifiLoc[0] + bleLoc[0]), 0.5 * (wifiLoc[1] + bleLoc[1])]
		},

		OfflineLoc_fusion(Current_loc) {
			var P = [
				[1, 0],
				[0, 1]
			]
			var Q = [
				[Math.pow(0.1, 2), 0],
				[0, Math.pow(0.1, 2)]
			]
			var R = [
				[Math.pow(3, 2), 0],
				[0, Math.pow(3, 2)]
			]

			var direction = this.Gyroscope_data.degree
			var that = this
			if (Current_loc == -1) return -1
			var t_direction = Math.PI * direction / 180
			var XY_ = [
				[Current_loc[0] + 0.65 * Math.cos(t_direction)],
				[Current_loc[1] + 0.65 * Math.sin(t_direction)]
			]
			var P_ = that.matrixAdd(P, Q)
			var K = that.matrixMul(P_, that.inv(that.matrixAdd(P_, R)))
			var XY_fp_XY_ = [
				[Current_loc[0] - XY_[0][0]],
				[Current_loc[1] - XY_[1][0]]
			]
			var XY = that.matrixAdd(XY_, that.matrixMul(K, XY_fp_XY_))
			var I_K = [
				[1 - K[0][0], -K[0][1]],
				[-K[1][0], 1 - K[1][1]]
			]
			P = that.matrixMul(I_K, P_)
			return [XY[0][0], XY[1][0]]
		},
		ss(rssi, coor) {
			for (var i = 0; i < rssi.length - 1; i++) {
				var min = i
				for (var j = i + 1; j < rssi.length; j++) {
					if (rssi[min] > rssi[j]) min = j
				}
				if (i != min) {
					var temp = rssi[i]
					rssi[i] = rssi[min]
					rssi[min] = temp
					temp = coor[i]
					coor[i] = coor[min]
					coor[min] = temp
				}
			}

			return rssi, coor

		},
		ls(coor, dis) {
			var that = this
			var A = [
				[2 * (coor[0][0] - coor[3][0]), 2 * (coor[0][1] - coor[3][1])],
				[2 * (coor[1][0] - coor[3][0]), 2 * (coor[1][1] - coor[3][1])],
				[2 * (coor[2][0] - coor[3][0]), 2 * (coor[2][1] - coor[3][1])]
			]
			var b = [
				[coor[0][0] * coor[0][0] - coor[3][0] * coor[3][0] + coor[0][1] * coor[0][1] - coor[3][1] * coor[3]
					[1] + dis[3] * dis[3] - dis[0] * dis[0]
				],
				[coor[1][0] * coor[1][0] - coor[3][0] * coor[3][0] + coor[1][1] * coor[1][1] - coor[3][1] * coor[3]
					[1] + dis[3] * dis[3] - dis[1] * dis[1]
				],
				[coor[2][0] * coor[2][0] - coor[3][0] * coor[3][0] + coor[2][1] * coor[2][1] - coor[3][1] * coor[3]
					[1] + dis[3] * dis[3] - dis[2] * dis[2]
				]
			]
			var AT = [
				[2 * (coor[0][0] - coor[3][0]), 2 * (coor[1][0] - coor[3][0]), 2 * (coor[2][0] - coor[3][0])],
				[2 * (coor[0][1] - coor[3][1]), 2 * (coor[1][1] - coor[3][1]), 2 * (coor[2][1] - coor[3][1])]
			]
			var ATA = that.matrixMul(AT, A)
			var ATA_i = that.inv(ATA)
			var result = that.matrixMul(that.matrixMul(ATA_i, AT), b)
			return [result[0][0], result[1][0]]
		},
		matrixMul(a, b) {
			var c = new Array(a.length)
			for (var i = 0; i < a.length; i++) {
				c[i] = new Array(b[0].length)
				for (var j = 0; j < b[0].length; j++) {
					c[i][j] = 0
					for (var k = 0; k < b.length; k++) c[i][j] += a[i][k] * b[k][j]
				}
			}
			return c
		},
		inv(a) {
			var a_i = [
				[(a[1][1]) / (a[1][1] * a[0][0] - a[0][1] * a[1][0]), (-1 * a[0][1]) / (a[1][1] * a[0][0] - a[0][
					1
				] * a[1][0])],
				[(-1 * a[1][0]) / (a[1][1] * a[0][0] - a[0][1] * a[1][0]), (a[0][0]) / (a[1][1] * a[0][0] - a[0][
					1
				] * a[1][0])]
			]
			return a_i
		},
		matrixAdd(a, b) {
			var c = new Array(a.length)
			for (var i = 0; i < a.length; i++) {
				c[i] = new Array(a[0].length)
				for (var j = 0; j < a[0].length; j++) {
					c[i][j] = a[i][j] + b[i][j]
				}
			}
			return c
		},
		//-------------------------------------------离线定位------------------------------------------------------------------
		// ————————————————————————————传感器信息相关方法——————————————————————————
		// 获取连接wifi、加速计、罗盘、陀螺仪信息
		getLocationOffline() {
			// #ifdef APP-PLUS
			this.getConnectedWiFi()
			// #endif
			// 设备信息
			const deviceInfo = uni.getDeviceInfo()
			//  加速计
			uni.onAccelerometerChange(res => {
				this.Accelerometer_data = res
			});
			//  罗盘
			uni.onCompassChange(res => {
				this.Compass_data = res
			})
			// 陀螺仪
			this.getGyroscope()
		},
		// 扫描WiFi列表，并将数据存储到wifiList中，根据信号强度排序
		getScanedWiFi() {
			var MainActivity = plus.android.runtimeMainActivity()
			var Context = plus.android.importClass('android.content.Context')
			plus.android.importClass("android.net.wifi.WifiManager")
			plus.android.importClass("android.net.wifi.WifiInfo")
			plus.android.importClass("android.net.wifi.ScanResult")
			plus.android.importClass("java.util.ArrayList")
			// 获取 WIFI 管理实例  
			var wifiManager = MainActivity.getSystemService(Context.WIFI_SERVICE)
			wifiManager.disconnect();
			wifiManager.startScan()
			var resultList = wifiManager.getScanResults()
			var len = resultList.size()
			this.wifiList = []
			for (var i = 0; i < len; i++) {
				this.wifiList.push({
					BSSID: resultList.get(i).plusGetAttribute('BSSID'),
					level: resultList.get(i).plusGetAttribute('level')
				})
			}
			this.wifiList.sort(function(x, y) {
				return -y.level + x.level;
			});
		},
		// 获取已连接的WiFi的信息，会因为WiFi断开连接而偶尔出现空消息的情况
		getConnectedWiFi() {
			var MainActivity = plus.android.runtimeMainActivity()
			var Context = plus.android.importClass('android.content.Context')
			plus.android.importClass("android.net.wifi.WifiManager")
			plus.android.importClass("android.net.wifi.WifiInfo")
			var wifiManager = MainActivity.getSystemService(Context.WIFI_SERVICE)
			var wifiInfo = wifiManager.getConnectionInfo()
			this.connectWifiInfo['BSSID'] = wifiInfo.getBSSID()
			this.connectWifiInfo['level'] = wifiInfo.getRssi()
		},
		// 调用原生插件获取陀螺仪信息
		getGyroscope() {
			var testModule = uni.requireNativePlugin("Huiy-SensorModule")
			testModule.registerSensorAFunc(
				(ret) => {
					this.Gyroscope_data.x = ret.x
					this.Gyroscope_data.y = ret.y
					this.Gyroscope_data.z = ret.z
					this.Gyroscope_data.degree = ret.degree
				})
			var ret = testModule.unRegisterSensorFunc();

		},
		// ————————————————————————————画布相关方法——————————————————————————————
		// 动态设置画布高度
		setCanvasHeight() {
			uni.getImageInfo({
				src: this.img_path,
				success: imgInfo => {
					// 动态获取图片的长宽
					const query = uni.createSelectorQuery().in(this);
					query.select('.loc-map').boundingClientRect((pos) => {
						this.imagePos.width = pos.width
						this.imagePos.height = pos.width * (imgInfo.height / imgInfo.width)
						this.mapRate = (this.mapFormData.mapX / pos.width + this
							.mapFormData.mapY /
							pos.height) / 2
					}).exec()
				}
			})
		},
		// 在画布上绘制用户位置方法
		// direction表示朝向，顺时针0-360°
		doUserDraw(x, y, direction) {
			// 坐标比例
			x = x / this.mapRate
			y = y / this.mapRate
			ctx.save();
			ctx.clearRect(0, 0, 1000, 2000)
			ctx.beginPath();
			ctx.translate(x, y);
			//先画个圆
			ctx.arc(0, 0, this.radis, 0, Math.PI * 2);
			ctx.setFillStyle('#ccc')
			ctx.setShadow(0, 0, 30, '#ff5500')
			ctx.fill()
			ctx.clip();
			// 旋转
			ctx.rotate((direction * Math.PI) / 180);
			ctx.drawImage(this.url + this.userInfo.avatar, -this.radis, -this.radis, 2 * this.radis, 2 * this
				.radis) // 推进去图片
			ctx.restore();
			ctx.draw();
		},
		// 绘Ap方法
		doApDraw(APList) {
			// 坐标比例
			ctx.save();
			ctx.clearRect(0, 0, 1000, 2000)
			ctx.beginPath();
			APList.forEach(ap => {
				var x = ap.apX / this.mapRate
				var y = ap.apY / this.mapRate
				ctx.drawImage('../../static/map_icon/ap.png', x, y, 2 * this.radis * 1.5, 2 * this
					.radis * 1.5) // 推进去图片
			})
			ctx.restore();
			ctx.draw();
		},
		clearDraw() {
			// 坐标比例
			ctx.save();
			ctx.clearRect(0, 0, 1000, 2000)
			ctx.beginPath();
			ctx.restore();
			ctx.draw();
		}
	}
}
