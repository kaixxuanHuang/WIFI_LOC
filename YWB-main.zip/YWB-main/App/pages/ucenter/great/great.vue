<template>
	<view class="center-great">
		<text class="great-title">关于GREAT实验室</text>
		<image src="../../../static/uni-center/great_lab.jpg" mode="widthFix"></image>
		<text>扫描二维码关注上海大学通信学院GREAT实验室</text>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>
	.center-great {
		display: flex;
		flex-direction: column;
		align-items: center;
		padding: 30rpx;
	}

	.center-great image {
		width: 500rpx;
		height: 500rpx;
		margin-bottom: 30rpx;
	}

	.great-title {
		font-weight: 600;
		font-size: 14pt;
		margin-bottom: 30rpx;
	}
</style>
