<template>
	<view class="loc-container" :style="'height:'+this.imagePos.height+250+'px;'">
		<image class="loc-map" :src='img_path' mode="widthFix"></image>
		<canvas canvas-id="myCanvas" :style="'height:'+this.imagePos.height+'px;'+'width:730rpx'" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// 地图在服务器上的路径
				img_path: '',
				// 显示出来的图片宽高
				imagePos: {},
				// 地图比例，暂时计算方式为x和y轴的比例平均
				mapRate: 1,
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
