<template>
	<view class="center-instruction">
		<image src="../../../static/uni-center/specification.png" mode="widthFix"></image>
		<view class="instruction-text">
			<view class="instruction-line">
				<text>Version: </text>
				<text>v1.1.4体验版\n</text>
			</view>
			<view class="instruction-line">
				<text>说明文档更新时间: </text>
				<text>2021年5月12日\n</text>
			</view>
			<view class="instruction-line">
				<text>开发人员: </text>
				<text>上海大学通信与信息系统学院GREAT实验室\n</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>
	.center-instruction {
		padding: 10rpx;
	}

	.center-instruction image {
		width: 100%;
	}

	.instruction-text {
		font-size: 13pt;
		margin: 0 30rpx;
	}

	.instruction-line {
		margin-bottom: 10rpx;
	}

	.instruction-line text {
		margin-right: 15rpx;
	}

	.instruction-line text:first-child {
		font-weight: 600;
	}
</style>
