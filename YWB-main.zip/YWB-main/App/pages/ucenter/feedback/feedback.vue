<template>
	<view class="center-feedback">
		<uni-forms ref="form" :modelValue="formData" :rules="rules" labelWidth="75px" err-show-type="toast">
			<uni-forms-item label="留言内容/回复内容" name="content">
				<uni-easyinput type="textarea" v-model="formData.content" />
			</uni-forms-item>
			<uni-forms-item label="图片列表" name="image">
				<uni-file-picker limit="9"></uni-file-picker>
			</uni-forms-item>
			<uni-forms-item label="联系人" name="name">
				<uni-easyinput type="text" v-model="formData.name" placeholder="请输入姓名" />
			</uni-forms-item>
			<uni-forms-item label="联系电话" name="phone">
				<uni-easyinput type="text" v-model="formData.phone" placeholder="请输入联系电话" />
			</uni-forms-item>
		</uni-forms>
		<button @click="submit" type="primary" size="default">提交</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				formData: {
					content: '',
					name: '',
					phone: ''
				},
				rules: {
					content: {
						rules: [{
							required: true,
							errorMessage: '留言内容/回复内容必填',
						}]
					},
					name: {
						rules: [{
								required: true,
								errorMessage: '请输入姓名',
							},
							{
								minLength: 3,
								maxLength: 7,
								errorMessage: '姓名长度在 {minLength} 到 {maxLength} 个字符',
							}
						]
					},
					phone: {
						rules: [{
							format: 'number',
							errorMessage: '请输入正确的联系电话',
						}]
					}
				}
			}
		},
		methods: {
			submit() {
				this.$refs.form.validate().then(res => {
					console.log('表单数据信息：', res);
				}).catch(err => {
					console.log('表单错误信息：', err);
				})
			}
		}
	}
</script>

<style>
	.center-feedback {
		padding: 30rpx;
	}
</style>
