<template>
	<view class="content">
		<!-- 功能列表 -->
		<uni-list class="mt10" :border="false">
			<uni-list-item title="头像" link>
				<template v-slot:footer>
					<image style="width: 60rpx; height:60rpx;" class="slot-image" :src="url+userInfo.avatar"
						mode="widthFix"></image>
				</template>
			</uni-list-item>
			<uni-list-item title="用户名" :rightText="userInfo.userName" link></uni-list-item>
			<uni-list-item title="昵称" :rightText="userInfo.nickName" link></uni-list-item>
			<uni-list-item title="性别" :rightText="userInfo.sex=='0'?'男':'女'" link></uni-list-item>
			<uni-list-item title="手机号" :rightText="userInfo.phonenumber" link></uni-list-item>
			<uni-list-item title="登录IP" :rightText="userInfo.loginIp" link></uni-list-item>
			<uni-list-item title="登录时间" :rightText="userInfo.loginDate" link></uni-list-item>
			<!-- <uni-list-item v-if="userInfo" title="修改密码"
				:to="'/pages/ucenter/login-page/pwd-retrieve/pwd-retrieve?phoneNumber='+ userInfo.mobile"
				link="navigateTo"></uni-list-item> -->
		</uni-list>
		<uni-list class="mt10" :border="false">
			<!-- #ifndef H5 -->
			<!-- #ifdef APP-PLUS -->
			<!-- 检查push过程未结束不显示，push设置项 -->
			<uni-list-item title="清理缓存" @click="clearTmp" link></uni-list-item>
			<!-- <uni-list-item v-show="pushIsOn != 'wait'" :title="$t('settings.pushServer')"
				@click.native="pushIsOn?pushServer.off():pushServer.on()" showSwitch :switchChecked="pushIsOn">
			</uni-list-item> -->
			<!-- #endif -->
			<!-- <uni-list-item v-if="supportMode.includes('fingerPrint')" :title="$t('settings.fingerPrint')"
				@click.native="startSoterAuthentication('fingerPrint')" link></uni-list-item>
			<uni-list-item v-if="supportMode.includes('facial')" :title="$t('settings.facial')"
				@click="startSoterAuthentication('facial')" link></uni-list-item> -->
			<!-- #endif -->
			<!-- <uni-list-item v-if="i18nEnable" :title="$t('settings.changeLanguage')" @click="changeLanguage"
				:rightText="currentLanguage" link></uni-list-item> -->
		</uni-list>

		<!-- 退出/登录 按钮 -->
		<view class="bottom-back" @click="changeLoginState">
			<text class="bottom-back-text" v-if="hasLogin" @click="logout">退出登录</text>
			<text class="bottom-back-text" v-else>登录</text>
		</view>
	</view>
</template>

<script>
	import {
		mapMutations,
		mapGetters,
		mapState
	} from 'vuex'
	export default {
		data() {
			return {
				// pushServer: pushServer,
				supportMode: [],
				pushIsOn: "wait",
				currentLanguage: "",
				hasLogin: true
			}
		},
		computed: mapState([
			'userInfo', 'url'
		]),
		onLoad() {
			uni.setNavigationBarTitle({
				title: '设置'
			})
		},
		methods: {
			...mapMutations([
				'removeToken'
			]),
			async changeLoginState() {
				if (this.hasLogin) {
					// await mutations.logout()
				} else {
					uni.redirectTo({
						url: '/uni_modules/uni-id-pages/pages/login/login-withoutpwd',
					});
				}
			},
			logout() {
				this.removeToken()
				uni.reLaunch({
					url: '/pages/login/login'
				})
			},
			clearTmp() {
				uni.showLoading({
					title: this.$t('settings.clearing'),
					mask: true
				});
				uni.getSavedFileList({
					success: res => {
						if (res.fileList.length > 0) {
							uni.removeSavedFile({
								filePath: res.fileList[0].filePath,
								complete: res => {
									console.log(res);
									uni.hideLoading()
									uni.showToast({
										title: this.$t('settings.clearedSuccessed'),
										icon: 'none'
									});
								}
							});
						} else {
							uni.hideLoading()
							uni.showToast({
								title: this.$t('settings.clearedSuccessed'),
								icon: 'none'
							});
						}
					},
					complete: e => {
						console.log(e);
					}
				});
			}
		}
	}
</script>

<style>
	/* #ifndef APP-NVUE */
	page {
		flex: 1;
		width: 100%;
		height: 100%;
	}

	uni-button:after {
		border: none;
		border-radius: 0;
	}

	/* #endif */
	.content {
		/* #ifndef APP-NVUE */
		display: flex;
		width: 750rpx;
		height: 100vh;
		/* #endif */
		flex-direction: column;
		flex: 1;
		background-color: #F9F9F9;
	}

	.bottom-back {
		margin-top: 10px;
		width: 750rpx;
		height: 44px;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		justify-content: center;
		align-items: center;
		/* #ifndef APP-NVUE */
		border: none;
		/* #endif */
		border-width: 0;
		border-radius: 0;
		background-color: #FFFFFF;
	}

	.bottom-back-text {
		font-size: 33rpx;
	}

	.mt10 {
		margin-top: 10px;
	}

	/* #ifndef APP-NVUE  || VUE3 */
	.content ::v-deep .uni-list {
		background-color: #F9F9F9;
	}

	.content ::v-deep .uni-list-item--disabled,
	.list-item {
		height: 50px;
		margin-bottom: 1px;
	}

	/* #endif */
</style>
