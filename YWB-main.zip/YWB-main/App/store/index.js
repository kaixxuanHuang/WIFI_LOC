import {
	createStore
} from 'vuex'
import createPersistedState from 'vuex-persistedstate'
export default createStore({
	// #ifdef APP-PLUS
	plugins: [
		createPersistedState({
			storage: {
				getItem: key => uni.getStorageSync(key),
				setItem: (key, value) => uni.setStorageSync(key, value),
				removeItem: key => uni.removeStorageSync(key)
			}
		})
	],
	// #endif
	// #ifndef APP-PLUS
	plugins: [
		createPersistedState({
			storage: window.localStorage
		})
	],
	// #endif
	state: {
		// url: 'http://localhost:8088',
		url: 'http://47.96.139.212:8088',
		userInfo: {}, //用户信息,
		token: null,
		scene: null
	},
	mutations: {
		setToken(state, token) {
			state.token = token
		},
		setScene(state, scene) {
			state.scene = scene
		},
		removeToken(state) {
			state.token = null
		},
		setUserInfo(state, value) {
			state.userInfo = value
		}
	},
	getters: {
		getToken(state) {
			return state.token
		},
		getScene(state) {
			return state.scene
		},
		getUserInfo(state) {
			return state.userInfo
		}
	}
})
