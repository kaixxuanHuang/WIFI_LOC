const WebSocket = require("ws");
const express = require("express");
const app = express();
const http = require("http").Server(app);

app.use(express.static(__dirname + "/public"));

const dgram = require("dgram");
const server = dgram.createSocket("udp4");

// 端口设置
const udpPort = 9090;
const frontPort = 9091;
const webSocketPort = 9092;
// 后端限制比例
rate = 0.8;

const wss = new WebSocket.Server({ port: webSocketPort }); // WebSocket服务器端口

server.bind(udpPort);

wss.on("connection", (ws) => {
  console.log("WebSocket connected");

  server.on("message", (msg, rinfo) => {
    const message = msg.toString();
    // console.log(`Received message: ${message}`);
    if (Math.random() > rate) ws.send(message); // 发送消息到前端页面,略加限制
  });
});

http.listen(frontPort, () => {
  console.log(`Server listening on http://localhost:${frontPort}`);
});
