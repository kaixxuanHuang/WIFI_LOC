import socket
import json
import time
import random

UDP_IP = "127.0.0.1"
UDP_PORT = 9090
# 发送的点的个数、速度
point = 50
speed = 1000

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

x_list = []
y_list = []
tag_list = []
for i in range(point):
    tag_list.append(f"2da8a66ddc{i}")
    x_list.append(random.random())
    y_list.append(random.random())

while True:
    # 模拟定时发送数据
    index = int(random.random() * len(tag_list))
    tag_id = tag_list[index]
    map_id = '1158'
    x_list[index] = x_list[index] + (random.random()-0.4) / speed
    if x_list[index] > 1:
        x_list[index] = 0
    y_list[index] = y_list[index] + (random.random()-0.5) / speed
    if y_list[index] > 1:
        y_list[index] = 0
    coordinates = {
        'tag_id': tag_id,
        'map_id': map_id,
        'x': x_list[index],
        'y': y_list[index]
    }
    sock.sendto(json.dumps(coordinates).encode(), (UDP_IP, UDP_PORT))
    # time.sleep(0.001)
